interface HavePower {
    public int getRawPower();
    public boolean isStrongerThan(HavePower x);
}
